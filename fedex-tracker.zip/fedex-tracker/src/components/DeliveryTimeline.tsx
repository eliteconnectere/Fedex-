import { SHIPMENT_STATUSES } from "@/lib/tracking";
import { format, differenceInDays, differenceInHours } from "date-fns";
import { CheckCircle2, Circle, Clock } from "lucide-react";

interface Props {
  status: string;
  createdAt: string;
  estimatedDelivery: string | null;
}

export function DeliveryTimeline({ status, createdAt, estimatedDelivery }: Props) {
  const steps = SHIPMENT_STATUSES.filter((s) => s !== "Completed");
  let currentIndex = steps.indexOf(status as (typeof steps)[number]);
  if (status === "Completed") currentIndex = steps.length - 1;
  if (currentIndex < 0) currentIndex = 0;

  const progress = ((currentIndex + 1) / steps.length) * 100;

  // Estimated arrival countdown
  let etaLabel: string | null = null;
  let etaTone: "ok" | "soon" | "late" = "ok";
  if (estimatedDelivery) {
    const eta = new Date(estimatedDelivery);
    const now = new Date();
    const days = differenceInDays(eta, now);
    const hours = differenceInHours(eta, now);
    if (status === "Delivered" || status === "Completed") {
      etaLabel = "Delivered";
      etaTone = "ok";
    } else if (hours < 0) {
      etaLabel = `${Math.abs(days)} day${Math.abs(days) === 1 ? "" : "s"} overdue`;
      etaTone = "late";
    } else if (days === 0) {
      etaLabel = `Arriving today`;
      etaTone = "soon";
    } else if (days <= 2) {
      etaLabel = `Arriving in ${days} day${days === 1 ? "" : "s"}`;
      etaTone = "soon";
    } else {
      etaLabel = `Arriving in ${days} days`;
    }
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-5">
        <div>
          <h3 className="font-bold text-lg">Delivery Timeline</h3>
          <p className="text-xs text-muted-foreground">
            Shipped {format(new Date(createdAt), "PPP")}
            {estimatedDelivery && (
              <>
                {" "}· ETA {format(new Date(estimatedDelivery), "PPP")}
              </>
            )}
          </p>
        </div>
        {etaLabel && (
          <div
            className={[
              "inline-flex items-center gap-1.5 self-start rounded-full px-3 py-1 text-xs font-semibold border",
              etaTone === "ok" && "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
              etaTone === "soon" && "bg-primary/15 text-primary border-primary/30",
              etaTone === "late" && "bg-red-500/15 text-red-300 border-red-500/30",
            ]
              .filter(Boolean)
              .join(" ")}
          >
            <Clock className="h-3 w-3" />
            {etaLabel}
          </div>
        )}
      </div>

      {/* Progress bar */}
      <div className="h-2 w-full rounded-full bg-muted overflow-hidden mb-6">
        <div
          className="h-full bg-primary transition-all duration-700 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Steps */}
      <ol className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {steps.map((step, i) => {
          const done = i <= currentIndex;
          const current = i === currentIndex;
          return (
            <li
              key={step}
              className={[
                "flex items-start gap-2 rounded-lg p-2",
                current && "bg-primary/10",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              {done ? (
                <CheckCircle2
                  className={`h-4 w-4 mt-0.5 shrink-0 ${current ? "text-primary" : "text-emerald-400"}`}
                />
              ) : (
                <Circle className="h-4 w-4 mt-0.5 shrink-0 text-muted-foreground/50" />
              )}
              <span
                className={`text-xs leading-tight ${
                  current
                    ? "font-bold text-primary"
                    : done
                      ? "text-foreground"
                      : "text-muted-foreground"
                }`}
              >
                {step}
              </span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
