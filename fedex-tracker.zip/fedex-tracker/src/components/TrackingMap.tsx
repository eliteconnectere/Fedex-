import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";

export type Smoothness = "fluid" | "standard" | "instant";
export type Easing = "linear" | "ease-in-out" | "ease-out";

interface Props {
  lat?: number | null;
  lng?: number | null;
  label?: string;
  height?: number;
  smoothness?: Smoothness;
  easing?: Easing;
  debug?: boolean;
  route?: {
    fromLat: number;
    fromLng: number;
    toLat: number;
    toLng: number;
    startedAt: string | null;
    elapsedSeconds: number;
    durationSeconds: number;
    paused: boolean;
    completed: boolean;
  } | null;
}

// --- Web-Mercator helpers (matches Google Maps projection) ---
function project(lat: number, lng: number, zoom: number) {
  const scale = 256 * Math.pow(2, zoom);
  const x = ((lng + 180) / 360) * scale;
  const s = Math.sin((lat * Math.PI) / 180);
  const y = (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * scale;
  return { x, y };
}
function latLngToPixel(
  lat: number,
  lng: number,
  centerLat: number,
  centerLng: number,
  zoom: number,
  width: number,
  height: number,
) {
  const c = project(centerLat, centerLng, zoom);
  const p = project(lat, lng, zoom);
  return { x: p.x - c.x + width / 2, y: p.y - c.y + height / 2 };
}
function pickZoom(latA: number, lngA: number, latB: number, lngB: number, w: number, h: number) {
  const cLat = (latA + latB) / 2;
  const cLng = (lngA + lngB) / 2;
  for (let z = 15; z >= 1; z--) {
    const a = latLngToPixel(latA, lngA, cLat, cLng, z, w, h);
    const b = latLngToPixel(latB, lngB, cLat, cLng, z, w, h);
    const pad = 0.15;
    if (
      a.x > w * pad && a.x < w * (1 - pad) && a.y > h * pad && a.y < h * (1 - pad) &&
      b.x > w * pad && b.x < w * (1 - pad) && b.y > h * pad && b.y < h * (1 - pad)
    ) return z;
  }
  return 2;
}

function preset(s: Smoothness) {
  switch (s) {
    case "instant":  return { correctionCap: 1.0,  completionEaseMs: 0   };
    case "standard": return { correctionCap: 0.15, completionEaseMs: 300 };
    case "fluid":
    default:         return { correctionCap: 0.05, completionEaseMs: 600 };
  }
}

// Easing shapes the visual position along the polyline as a function of
// linear progress. All curves satisfy f(0)=0, f(1)=1 so the marker still
// arrives exactly on the destination pin.
function applyEasing(p: number, e: Easing): number {
  const x = Math.min(1, Math.max(0, p));
  switch (e) {
    case "ease-in-out":
      // Smooth sinusoidal — slow start, cruise, slow arrival
      return 0.5 - Math.cos(Math.PI * x) / 2;
    case "ease-out":
      // Fast off the line, gentle arrival
      return 1 - Math.pow(1 - x, 3);
    case "linear":
    default:
      return x;
  }
}

// Fixed green destination pin — the only stationary marker on the map.
function DestinationPin({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x - 12}, ${y - 30})`} style={{ filter: "drop-shadow(0 3px 5px rgba(0,0,0,0.5))" }}>
      <path
        d="M12 0C5.4 0 0 5.4 0 12c0 8.6 12 18 12 18s12-9.4 12-18C24 5.4 18.6 0 12 0z"
        fill="#22c55e"
        stroke="#000"
        strokeWidth="1.25"
      />
      <circle cx="12" cy="12" r="4.5" fill="#0f5132" />
    </g>
  );
}

// Injected once — keyframes for the live marker's radar ripple + gentle bounce.
const LIVE_MARKER_STYLES = `
@keyframes ups-ripple {
  0%   { transform: scale(0.6); opacity: 0.55; }
  80%  { transform: scale(2.2); opacity: 0; }
  100% { transform: scale(2.2); opacity: 0; }
}
@keyframes ups-glow {
  0%,100% { opacity: 0.55; }
  50%     { opacity: 0.9; }
}
@keyframes ups-bounce {
  0%, 70%, 100% { transform: translateY(0); }
  80%           { transform: translateY(-6px); }
  90%           { transform: translateY(-2px); }
}
`;



export default function TrackingMap({
  lat,
  lng,
  label,
  height = 360,
  route,
  smoothness = "fluid",
  easing = "linear",
  debug = false,
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [width, setWidth] = useState(0);

  useLayoutEffect(() => {
    if (!containerRef.current) return;
    const el = containerRef.current;
    const ro = new ResizeObserver(() => setWidth(el.clientWidth));
    ro.observe(el);
    setWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const isRoute =
    !!route &&
    route.durationSeconds > 0 &&
    Number.isFinite(route.fromLat) && Number.isFinite(route.toLat);

  const fromLat = isRoute ? route!.fromLat : 0;
  const fromLng = isRoute ? route!.fromLng : 0;
  const toLat   = isRoute ? route!.toLat : 0;
  const toLng   = isRoute ? route!.toLng : 0;

  const geom = useMemo(() => {
    if (!isRoute || width === 0) return null;
    const cLat = (fromLat + toLat) / 2;
    const cLng = (fromLng + toLng) / 2;
    const z = pickZoom(fromLat, fromLng, toLat, toLng, width, height);
    const from = latLngToPixel(fromLat, fromLng, cLat, cLng, z, width, height);
    const to = latLngToPixel(toLat, toLng, cLat, cLng, z, width, height);
    return { cLat, cLng, z, from, to };
  }, [isRoute, fromLat, fromLng, toLat, toLng, width, height]);

  const routeSrc = useMemo(() => {
    if (!geom) return null;
    const cLat = Math.round(geom.cLat * 10000) / 10000;
    const cLng = Math.round(geom.cLng * 10000) / 10000;
    // Use ll= (not q=) so Google does NOT drop its own red pin on the map.
    return `https://www.google.com/maps?ll=${cLat},${cLng}&z=${geom.z}&t=m&output=embed`;
  }, [geom?.cLat, geom?.cLng, geom?.z]);

  const staticSrc = useMemo(() => {
    if (isRoute) return null;
    const hasCoords = typeof lat === "number" && typeof lng === "number";
    if (hasCoords) {
      // ll= centers the map with no auto-pin; our overlay owns all markers.
      return `https://www.google.com/maps?ll=${lat},${lng}&z=8&t=m&output=embed`;
    }
    const q = encodeURIComponent(label ?? "");
    return `https://www.google.com/maps?q=${q}&z=13&output=embed`;
  }, [isRoute, lat, lng, label]);


  // rAF-driven marker/progress/polyline (direct DOM writes; no React state per frame)
  const markerRef = useRef<HTMLDivElement | null>(null);
  const progressBarRef = useRef<HTMLDivElement | null>(null);
  const progressLabelRef = useRef<HTMLSpanElement | null>(null);
  const traveledLineRef = useRef<SVGLineElement | null>(null);
  const dashedLineRef = useRef<SVGLineElement | null>(null);
  const diagRef = useRef<HTMLDivElement | null>(null);
  const displayedRef = useRef<number>(0);
  const speedMultRef = useRef<number>(1);
  const dashOffsetRef = useRef<number>(0);

  const routeRef = useRef(route);
  useEffect(() => { routeRef.current = route; }, [route]);
  const smoothnessRef = useRef(smoothness);
  useEffect(() => { smoothnessRef.current = smoothness; }, [smoothness]);
  const easingRef = useRef(easing);
  useEffect(() => { easingRef.current = easing; }, [easing]);
  const geomRef = useRef(geom);
  useEffect(() => { geomRef.current = geom; }, [geom]);

  useEffect(() => {
    if (!route || !route.durationSeconds) return;
    const nowMs = Date.now();
    const live =
      route.elapsedSeconds +
      (route.startedAt && !route.paused && !route.completed
        ? Math.max(0, (nowMs - new Date(route.startedAt).getTime()) / 1000)
        : 0);
    displayedRef.current = route.completed
      ? 1
      : Math.min(1, Math.max(0, live / route.durationSeconds));
  }, [route?.startedAt, route?.durationSeconds]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!isRoute) return;
    let rafId = 0;
    let lastT = performance.now();
    // FPS rolling window
    let frames = 0;
    let fpsWindowStart = lastT;
    let fps = 0;

    const tick = (t: number) => {
      const dt = Math.max(0, Math.min(0.25, (t - lastT) / 1000));
      lastT = t;
      frames++;
      if (t - fpsWindowStart >= 1000) {
        fps = (frames * 1000) / (t - fpsWindowStart);
        frames = 0;
        fpsWindowStart = t;
      }

      const r = routeRef.current;
      const g = geomRef.current;
      const easingMode = easingRef.current;
      const { correctionCap, completionEaseMs } = preset(smoothnessRef.current);

      if (!r || !g || !r.durationSeconds) {
        rafId = requestAnimationFrame(tick);
        return;
      }

      const cur = displayedRef.current;
      let next = cur;
      let serverProgress = cur;

      if (r.completed) {
        if (completionEaseMs <= 0) {
          next = 1;
        } else {
          const step = (dt * 1000) / completionEaseMs;
          next = Math.min(1, cur + step * (1 - cur + 0.001));
        }
        serverProgress = 1;
        speedMultRef.current = 1;
      } else if (r.paused || !r.startedAt) {
        next = cur;
        speedMultRef.current = 0;
      } else {
        const nominalSpeed = 1 / r.durationSeconds;
        const serverLive =
          r.elapsedSeconds +
          Math.max(0, (Date.now() - new Date(r.startedAt).getTime()) / 1000);
        serverProgress = Math.min(1, Math.max(0, serverLive / r.durationSeconds));

        const drift = serverProgress - cur;
        const desiredExtra = drift / Math.max(2, r.durationSeconds * 0.02);
        const clampedExtra = Math.max(-correctionCap, Math.min(correctionCap, desiredExtra));
        const speed = nominalSpeed * (1 + clampedExtra);
        speedMultRef.current = 1 + clampedExtra;

        next = Math.min(1, Math.max(0, cur + speed * dt));
      }

      displayedRef.current = next;

      const eased = applyEasing(next, easingMode);
      const x = g.from.x + (g.to.x - g.from.x) * eased;
      const y = g.from.y + (g.to.y - g.from.y) * eased;

      if (markerRef.current) {
        markerRef.current.style.transform = `translate(${x - 18}px, ${y - 42}px)`;
      }

      if (progressBarRef.current) {
        progressBarRef.current.style.width = `${eased * 100}%`;
      }
      if (progressLabelRef.current) {
        progressLabelRef.current.textContent = r.completed
          ? "· ✓ arrived"
          : r.paused
            ? "· paused"
            : `· en route ${Math.round(eased * 100)}%`;
      }
      // Traveled solid segment ends at marker.
      if (traveledLineRef.current) {
        traveledLineRef.current.setAttribute("x2", String(x));
        traveledLineRef.current.setAttribute("y2", String(y));
      }
      // Gentle dash flow toward destination for the remaining segment.
      if (dashedLineRef.current && !r.paused && !r.completed) {
        dashOffsetRef.current = (dashOffsetRef.current - dt * 24) % 14;
        dashedLineRef.current.setAttribute("stroke-dashoffset", String(dashOffsetRef.current));
      }

      if (debug && diagRef.current) {
        const drift = (serverProgress - next) * 100;
        diagRef.current.textContent =
          `fps ${fps.toFixed(0)}` +
          ` · local ${(next * 100).toFixed(1)}%` +
          ` · server ${(serverProgress * 100).toFixed(1)}%` +
          ` · drift ${drift >= 0 ? "+" : ""}${drift.toFixed(2)}%` +
          ` · ×${speedMultRef.current.toFixed(3)}` +
          ` · ${smoothnessRef.current}/${easingMode}` +
          (r.paused ? " · paused" : "") +
          (r.completed ? " · done" : "");
      }

      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [isRoute, debug]);

  const openHref = useMemo(() => {
    if (isRoute && route) {
      return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${route.fromLat},${route.fromLng}`)}`;
    }
    const q = encodeURIComponent(typeof lat === "number" && typeof lng === "number" ? `${lat},${lng}` : (label ?? ""));
    return `https://www.google.com/maps/search/?api=1&query=${q}`;
  }, [isRoute, route, lat, lng, label]);

  return (
    <div ref={containerRef} style={{ borderRadius: 12, overflow: "hidden", position: "relative", height }}>
      <iframe
        title="Google Map"
        src={(isRoute ? routeSrc : staticSrc) ?? "about:blank"}
        width="100%"
        height={height}
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        style={{ border: 0, display: "block" }}
      />

      {isRoute && geom && (
        <svg
          width={width}
          height={height}
          style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
        >
          {/* Soft shadow underlay for depth */}
          <line
            x1={geom.from.x} y1={geom.from.y}
            x2={geom.to.x} y2={geom.to.y}
            stroke="rgba(0,0,0,0.35)"
            strokeWidth={9}
            strokeLinecap="round"
            opacity={0.55}
          />
          {/* Remaining route — dashed, gently flowing */}
          <line
            ref={dashedLineRef}
            x1={geom.from.x} y1={geom.from.y}
            x2={geom.to.x} y2={geom.to.y}
            stroke="#FFCC00"
            strokeWidth={5}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="8 6"
            opacity={0.95}
          />
          {/* Traveled portion — solid, ends at marker */}
          <line
            ref={traveledLineRef}
            x1={geom.from.x} y1={geom.from.y}
            x2={geom.from.x} y2={geom.from.y}
            stroke="#FFCC00"
            strokeWidth={5}
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity={1}
          />
          {/* Destination pin (fixed green). Origin has no pin — the route line's start marks it. */}
          <DestinationPin x={geom.to.x} y={geom.to.y} />

        </svg>
      )}

      {/* Static destination label chip */}
      {isRoute && geom && (
        <div
          style={{
            position: "absolute",
            left: geom.to.x + 16,
            top: geom.to.y - 40,
            padding: "4px 8px",
            fontSize: 10.5,
            fontWeight: 700,
            background: "rgba(34,197,94,0.95)",
            color: "#fff",
            borderRadius: 6,
            boxShadow: "0 4px 10px rgba(0,0,0,0.3)",
            whiteSpace: "nowrap",
            pointerEvents: "none",
            zIndex: 2,
            letterSpacing: ".02em",
          }}
        >
          🏁 Destination
        </div>
      )}

      {isRoute && (
        <>
          <style>{LIVE_MARKER_STYLES}</style>
          <div
            ref={markerRef}
            style={{
              position: "absolute",
              left: 0,
              top: 0,
              transform: "translate(-9999px, -9999px)",
              willChange: "transform",
              pointerEvents: "none",
              width: 36,
              height: 42,
              zIndex: 3,
            }}
          >
            {/* Radar ripples — two staggered rings behind the pin */}
            <div
              style={{
                position: "absolute",
                left: 18,
                top: 32,
                width: 20,
                height: 20,
                marginLeft: -10,
                marginTop: -10,
                borderRadius: "50%",
                background: "rgba(212,5,17,0.45)",
                animation: "ups-ripple 1.8s ease-out infinite",
              }}
            />
            <div
              style={{
                position: "absolute",
                left: 18,
                top: 32,
                width: 20,
                height: 20,
                marginLeft: -10,
                marginTop: -10,
                borderRadius: "50%",
                background: "rgba(212,5,17,0.35)",
                animation: "ups-ripple 1.8s ease-out 0.9s infinite",
              }}
            />
            {/* Always-on glow ring */}
            <div
              style={{
                position: "absolute",
                left: 18,
                top: 32,
                width: 26,
                height: 26,
                marginLeft: -13,
                marginTop: -13,
                borderRadius: "50%",
                boxShadow: "0 0 0 2px rgba(212,5,17,0.35), 0 0 14px 4px rgba(212,5,17,0.55)",
                animation: "ups-glow 2s ease-in-out infinite",
              }}
            />
            {/* Bouncing pin wrapper (does not fight outer positional transform) */}
            <div
              style={{
                position: "absolute",
                left: 0,
                top: 0,
                width: 36,
                height: 42,
                animation: "ups-bounce 2.5s ease-in-out infinite",
                filter: "drop-shadow(0 5px 7px rgba(0,0,0,0.5))",
              }}
            >
              <svg viewBox="0 0 28 32" width="36" height="42">
                <path
                  d="M14 0C6.3 0 0 6.3 0 14c0 10 14 18 14 18s14-8 14-18C28 6.3 21.7 0 14 0z"
                  fill="#D40511"
                  stroke="#000"
                  strokeWidth="1"
                />
                <circle cx="14" cy="14" r="5.5" fill="#7a0308" />
              </svg>
            </div>
            {/* Floating "Live Package Location" chip beside marker */}
            <div
              style={{
                position: "absolute",
                left: 42,
                top: 4,
                padding: "4px 8px",
                fontSize: 10.5,
                fontWeight: 700,
                background: "rgba(212,5,17,0.95)",
                color: "#fff",
                borderRadius: 6,
                boxShadow: "0 4px 10px rgba(0,0,0,0.35)",
                whiteSpace: "nowrap",
                letterSpacing: ".02em",
              }}
            >
              🚚 Live Package
            </div>
          </div>
        </>
      )}


      {label && (
        <div
          style={{
            position: "absolute",
            left: 12,
            top: 12,
            maxWidth: "calc(100% - 24px)",
            padding: "7px 10px",
            fontSize: 12,
            fontWeight: 700,
            background: "rgba(0,0,0,0.78)",
            color: "#fff",
            borderRadius: 8,
            boxShadow: "0 8px 22px rgba(0,0,0,0.22)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          📍 {label}
          {isRoute && (
            <span ref={progressLabelRef} style={{ marginLeft: 8, opacity: 0.85 }}>
              · en route 0%
            </span>
          )}
        </div>
      )}

      {isRoute && !route?.completed && (
        <div
          style={{
            position: "absolute",
            left: 12,
            right: 12,
            bottom: 44,
            height: 6,
            borderRadius: 999,
            background: "rgba(255,255,255,0.25)",
            overflow: "hidden",
          }}
        >
          <div
            ref={progressBarRef}
            style={{
              width: "0%",
              height: "100%",
              background: "linear-gradient(90deg,#FFCC00,#D40511)",
              willChange: "width",
            }}
          />
        </div>
      )}

      {debug && isRoute && (
        <div
          ref={diagRef}
          style={{
            position: "absolute",
            right: 12,
            top: 12,
            padding: "6px 8px",
            fontSize: 10,
            fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
            fontWeight: 600,
            background: "rgba(0,0,0,0.78)",
            color: "#FFCC00",
            borderRadius: 6,
            letterSpacing: ".02em",
            maxWidth: "70%",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          diagnostics…
        </div>
      )}

      <a
        href={openHref}
        target="_blank"
        rel="noreferrer"
        style={{
          position: "absolute",
          right: 12,
          bottom: 12,
          padding: "6px 10px",
          fontSize: 11,
          fontWeight: 700,
          background: "rgba(0,0,0,0.75)",
          color: "#fff",
          borderRadius: 8,
          textDecoration: "none",
          letterSpacing: ".05em",
        }}
      >
        OPEN IN GOOGLE MAPS
      </a>
    </div>
  );
}
