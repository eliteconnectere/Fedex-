import { Link } from "@tanstack/react-router";

export function Brand({ subtitle }: { subtitle?: string }) {
  return (
    <Link to="/" className="inline-flex items-center gap-3 group">
      <div className="leading-tight">
        <div className="font-black tracking-tight text-3xl leading-none">
          <span style={{ color: "#4D148C" }}>Fed</span>
          <span style={{ color: "#FF6600" }}>Ex</span>
        </div>
        {subtitle && (
          <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground mt-1">
            {subtitle}
          </div>
        )}
      </div>
    </Link>
  );
}
