export interface GeocodeResult {
  display_name: string;
  lat: number;
  lng: number;
}

export async function geocode(query: string): Promise<GeocodeResult[]> {
  const trimmed = query.trim();
  if (!trimmed) return [];

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 8000);

  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(trimmed)}`;
    const res = await fetch(url, { headers: { Accept: "application/json" }, signal: controller.signal });
    if (!res.ok) {
      throw new Error(`Location search failed (${res.status})`);
    }
    const data = (await res.json()) as Array<{ display_name: string; lat: string; lon: string }>;
    return data
      .map((d) => ({ display_name: d.display_name, lat: parseFloat(d.lat), lng: parseFloat(d.lon) }))
      .filter((d) => Number.isFinite(d.lat) && Number.isFinite(d.lng));
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error("Location search timed out. The typed location can still be saved without coordinates.");
    }
    if (error instanceof Error) throw error;
    throw new Error("Location search failed. The typed location can still be saved without coordinates.");
  } finally {
    window.clearTimeout(timeout);
  }
}
