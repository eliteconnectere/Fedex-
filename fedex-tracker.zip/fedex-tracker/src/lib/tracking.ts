export function generateTrackingNumber(): string {
  // FedEx-style: "FX" + 12 digits
  const digits = Array.from({ length: 12 }, () => Math.floor(Math.random() * 10)).join("");
  return `FX${digits}`;
}


export const SHIPMENT_STATUSES = [
  "Shipment Created",
  "Package Received",
  "Processing",
  "In Transit",
  "Arrived at Facility",
  "Out for Delivery",
  "Delivered",
  "Completed",
] as const;

export type ShipmentStatus = (typeof SHIPMENT_STATUSES)[number];
