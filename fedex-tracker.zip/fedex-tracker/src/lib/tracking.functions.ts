import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const getPublicShipment = createServerFn({ method: "GET" })
  .inputValidator(z.object({ tracking: z.string().min(1).max(64) }))
  .handler(async ({ data }) => {
    const tracking = data.tracking.trim().toUpperCase();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: shipment, error } = await supabaseAdmin
      .from("shipments")
      .select("*")
      .eq("tracking_number", tracking)
      .maybeSingle();

    if (error) throw error;
    if (!shipment) return null;

    const { data: events, error: eventsError } = await supabaseAdmin
      .from("tracking_events")
      .select("*")
      .eq("shipment_id", shipment.id)
      .order("created_at", { ascending: false });

    if (eventsError) throw eventsError;

    return {
      id: shipment.id,
      tracking_number: shipment.tracking_number,
      status: shipment.status,
      sender_name: shipment.sender_name,
      recipient_name: shipment.recipient_name,
      recipient_address: shipment.recipient_address,
      origin: shipment.origin,
      destination: shipment.destination,
      package_description: shipment.package_description,
      weight_kg: shipment.weight_kg,
      current_location_name: shipment.current_location_name,
      current_lat: shipment.current_lat,
      current_lng: shipment.current_lng,
      estimated_delivery: shipment.estimated_delivery,
      created_at: shipment.created_at,
      updated_at: shipment.updated_at,
      route_from_lat: (shipment as { route_from_lat?: number | null }).route_from_lat ?? null,
      route_from_lng: (shipment as { route_from_lng?: number | null }).route_from_lng ?? null,
      route_from_name: (shipment as { route_from_name?: string | null }).route_from_name ?? null,
      route_to_lat: (shipment as { route_to_lat?: number | null }).route_to_lat ?? null,
      route_to_lng: (shipment as { route_to_lng?: number | null }).route_to_lng ?? null,
      route_to_name: (shipment as { route_to_name?: string | null }).route_to_name ?? null,
      route_duration_seconds: (shipment as { route_duration_seconds?: number | null }).route_duration_seconds ?? null,
      route_started_at: (shipment as { route_started_at?: string | null }).route_started_at ?? null,
      route_elapsed_seconds: (shipment as { route_elapsed_seconds?: number | null }).route_elapsed_seconds ?? 0,
      route_paused: (shipment as { route_paused?: boolean | null }).route_paused ?? false,
      route_completed: (shipment as { route_completed?: boolean | null }).route_completed ?? false,
      animation_smoothness: ((shipment as { animation_smoothness?: string | null }).animation_smoothness ?? "fluid") as "fluid" | "standard" | "instant",
      animation_easing: ((shipment as { animation_easing?: string | null }).animation_easing ?? "linear") as "linear" | "ease-in-out" | "ease-out",
      events: events ?? [],
    };
  });