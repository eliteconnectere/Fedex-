import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { generateTrackingNumber } from "@/lib/tracking";
import { Plus, LogOut, Copy, Package, Search, Pencil, ChevronRight } from "lucide-react";
import { format } from "date-fns";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({ meta: [{ title: "Admin Dashboard — UPS" }] }),
  component: AdminDashboard,
});

interface ShipmentRow {
  id: string;
  tracking_number: string;
  status: string;
  recipient_name: string | null;
  destination: string | null;
  current_location_name: string | null;
  updated_at: string;
}

function AdminDashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");

  const { data: shipments = [], isLoading } = useQuery({
    queryKey: ["admin-shipments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("shipments")
        .select("id, tracking_number, status, recipient_name, destination, current_location_name, updated_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as ShipmentRow[];
    },
  });

  const filtered = shipments.filter((s) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      s.tracking_number.toLowerCase().includes(q) ||
      (s.recipient_name ?? "").toLowerCase().includes(q) ||
      (s.destination ?? "").toLowerCase().includes(q)
    );
  });

  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <div className="min-h-screen">
      <header className="mx-auto max-w-6xl px-5 py-6 flex items-center justify-between">
        <Brand subtitle="Admin Console" />
        <div className="flex items-center gap-3">
          <Link to="/" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-primary">
            Customer site
          </Link>
          <Button variant="ghost" size="sm" onClick={signOut}>
            <LogOut className="h-4 w-4 mr-1" /> Sign out
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-16">
        <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between mb-6">
          <div>
            <h1 className="text-3xl font-black tracking-tight">Shipments</h1>
            <p className="text-sm text-muted-foreground">Create and manage tracking records.</p>
          </div>
          <CreateShipmentDialog />
        </div>

        <div className="relative mb-4">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by tracking number, recipient, destination…"
            className="pl-10 h-11 bg-card"
          />
        </div>

        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-muted-foreground">Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="p-12 text-center">
              <Package className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
              <div className="font-semibold">No shipments yet</div>
              <div className="text-sm text-muted-foreground">Create your first shipment to get started.</div>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {filtered.map((s) => (
                <a
                  key={s.id}
                  href={`/admin/${s.id}`}
                  className="group flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 px-5 py-4 hover:bg-secondary/60 active:bg-secondary transition-colors cursor-pointer"
                >
                  <div className="flex-1 min-w-0">
                    <div className="font-mono font-bold tracking-wider text-primary group-hover:underline">
                      {s.tracking_number}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      {s.recipient_name ?? "—"} · {s.destination ?? "—"}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground sm:w-44 truncate">
                    {s.current_location_name ?? "No location"}
                  </div>
                  <Badge className="bg-primary/15 text-primary border-primary/30 self-start">{s.status}</Badge>
                  <div className="text-xs text-muted-foreground sm:w-28 text-right hidden sm:block">
                    {format(new Date(s.updated_at), "MMM d, HH:mm")}
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-widest text-primary border border-primary/40 rounded-full px-3 py-1 self-start sm:self-auto">
                    <Pencil className="h-3 w-3" /> Edit
                    <ChevronRight className="h-3 w-3" />
                  </span>
                </a>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function CreateShipmentDialog() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    sender_name: "",
    recipient_name: "",
    recipient_address: "",
    origin: "",
    destination: "",
    package_description: "",
    weight_kg: "",
    estimated_delivery: "",
  });
  const [tn, setTn] = useState(generateTrackingNumber());

  const onCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("shipments")
        .insert({
          tracking_number: tn,
          sender_name: form.sender_name || null,
          recipient_name: form.recipient_name || null,
          recipient_address: form.recipient_address || null,
          origin: form.origin || null,
          destination: form.destination || null,
          package_description: form.package_description || null,
          weight_kg: form.weight_kg ? Number(form.weight_kg) : null,
          estimated_delivery: form.estimated_delivery || null,
          status: "Shipment Created",
          created_by: userData.user?.id,
        })
        .select("id")
        .single();
      if (error) throw error;
      toast.success(`Shipment created · ${tn}`);
      await qc.invalidateQueries({ queryKey: ["admin-shipments"] });
      setOpen(false);
      navigate({ to: "/admin/$id", params: { id: data.id } });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to create");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (o) setTn(generateTrackingNumber()); }}>
      <DialogTrigger asChild>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
          <Plus className="h-4 w-4 mr-1" /> New shipment
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Create shipment</DialogTitle>
        </DialogHeader>
        <form onSubmit={onCreate} className="space-y-3">
          <div>
            <Label>Tracking Number</Label>
            <div className="flex gap-2 mt-1">
              <Input value={tn} readOnly className="font-mono font-bold tracking-wider bg-muted" />
              <Button type="button" variant="outline" size="icon" onClick={() => { navigator.clipboard.writeText(tn); toast.success("Copied"); }}>
                <Copy className="h-4 w-4" />
              </Button>
              <Button type="button" variant="outline" onClick={() => setTn(generateTrackingNumber())}>
                Regenerate
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Sender</Label><Input value={form.sender_name} onChange={(e) => setForm({ ...form, sender_name: e.target.value })} /></div>
            <div><Label>Recipient</Label><Input value={form.recipient_name} onChange={(e) => setForm({ ...form, recipient_name: e.target.value })} /></div>
          </div>
          <div><Label>Recipient Address</Label><Input value={form.recipient_address} onChange={(e) => setForm({ ...form, recipient_address: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Origin</Label><Input value={form.origin} onChange={(e) => setForm({ ...form, origin: e.target.value })} /></div>
            <div><Label>Destination</Label><Input value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} /></div>
          </div>
          <div><Label>Package description</Label><Textarea rows={2} value={form.package_description} onChange={(e) => setForm({ ...form, package_description: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Weight (kg)</Label><Input type="number" step="0.01" value={form.weight_kg} onChange={(e) => setForm({ ...form, weight_kg: e.target.value })} /></div>
            <div><Label>Estimated delivery</Label><Input type="date" value={form.estimated_delivery} onChange={(e) => setForm({ ...form, estimated_delivery: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading} className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
              {loading ? "Creating…" : "Create shipment"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}