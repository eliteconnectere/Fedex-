import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, lazy, Suspense, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { ArrowLeft, MapPin, Search, Copy, Trash2, Clock, Pencil, Zap, Play, Pause, X, Route as RouteIcon } from "lucide-react";
import { format } from "date-fns";
import { SHIPMENT_STATUSES } from "@/lib/tracking";
import { geocode, type GeocodeResult } from "@/lib/geocode";
import { processDueScheduledUpdates } from "@/lib/admin.functions";
import { countriesConflict, extractCountry } from "@/lib/country";

const TrackingMap = lazy(() => import("@/components/TrackingMap"));

export const Route = createFileRoute("/_authenticated/admin/$id")({
  component: ManageShipment,
});

function formatDuration(sec: number | null | undefined) {
  if (!sec || sec <= 0) return "—";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts: string[] = [];
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (s || parts.length === 0) parts.push(`${s}s`);
  return parts.join(" ");
}

interface Event {
  id: string;
  status: string;
  location_name: string | null;
  lat: number | null;
  lng: number | null;
  notes: string | null;
  created_at: string;
}

interface Shipment {
  id: string;
  tracking_number: string;
  status: string;
  current_location_name: string | null;
  current_lat: number | null;
  current_lng: number | null;
  recipient_name: string | null;
  recipient_address: string | null;
  destination: string | null;
  origin: string | null;
  estimated_delivery: string | null;
  created_at: string;
  updated_at: string;
  route_from_lat: number | null;
  route_from_lng: number | null;
  route_from_name: string | null;
  route_to_lat: number | null;
  route_to_lng: number | null;
  route_to_name: string | null;
  route_duration_seconds: number | null;
  route_started_at: string | null;
  route_elapsed_seconds: number | null;
  route_paused: boolean | null;
  route_completed: boolean | null;
  animation_smoothness?: "fluid" | "standard" | "instant" | null;
  animation_easing?: "linear" | "ease-in-out" | "ease-out" | null;
}

interface ScheduledUpdate {
  id: string;
  scheduled_for: string;
  status: string | null;
  location_name: string | null;
  lat: number | null;
  lng: number | null;
  notes: string | null;
  applied_at: string | null;
}

function ManageShipment() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const runDueScheduledUpdates = useServerFn(processDueScheduledUpdates);

  const { data, isLoading } = useQuery({
    queryKey: ["shipment", id],
    queryFn: async () => {
      const { data: s, error } = await supabase.from("shipments").select("*").eq("id", id).single();
      if (error) throw error;
      const { data: events } = await supabase
        .from("tracking_events").select("*").eq("shipment_id", id).order("created_at", { ascending: false });
      const { data: sched } = await supabase
        .from("scheduled_updates").select("*").eq("shipment_id", id).order("scheduled_for", { ascending: true });
      return {
        shipment: s as Shipment,
        events: (events ?? []) as Event[],
        scheduled: (sched ?? []) as ScheduledUpdate[],
      };
    },
  });

  // --- Manual update form ---
  const [status, setStatus] = useState<string>("");
  const [locQuery, setLocQuery] = useState("");
  const [locResults, setLocResults] = useState<GeocodeResult[]>([]);
  const [picked, setPicked] = useState<GeocodeResult | null>(null);
  const [notes, setNotes] = useState("");
  const [estimatedDelivery, setEstimatedDelivery] = useState("");
  const [searching, setSearching] = useState(false);
  const [updating, setUpdating] = useState(false);

  // --- Schedule form ---
  const [schedWhen, setSchedWhen] = useState<string>("");
  const [schedStatus, setSchedStatus] = useState<string>("");
  const [schedLocQuery, setSchedLocQuery] = useState("");
  const [schedLocResults, setSchedLocResults] = useState<GeocodeResult[]>([]);
  const [schedPicked, setSchedPicked] = useState<GeocodeResult | null>(null);
  const [schedNotes, setSchedNotes] = useState("");
  const [schedSaving, setSchedSaving] = useState(false);

  // --- Auto-route form ---
  const [routeFromQuery, setRouteFromQuery] = useState("");
  const [routeFromPicked, setRouteFromPicked] = useState<GeocodeResult | null>(null);
  const [routeFromResults, setRouteFromResults] = useState<GeocodeResult[]>([]);
  const [routeToQuery, setRouteToQuery] = useState("");
  const [routeToPicked, setRouteToPicked] = useState<GeocodeResult | null>(null);
  const [routeToResults, setRouteToResults] = useState<GeocodeResult[]>([]);
  const [routeH, setRouteH] = useState<string>("1");
  const [routeM, setRouteM] = useState<string>("0");
  const [routeS, setRouteS] = useState<string>("0");
  const [routeSaving, setRouteSaving] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  const shipment = data?.shipment;
  const events = data?.events ?? [];
  const scheduled = data?.scheduled ?? [];

  useEffect(() => {
    if (shipment?.estimated_delivery) {
      setEstimatedDelivery(shipment.estimated_delivery.slice(0, 10));
    } else {
      setEstimatedDelivery("");
    }
  }, [shipment?.id, shipment?.estimated_delivery]);

  // Realtime refresh + route-completion notification
  const prevCompletedRef = useRef<boolean | null>(null);
  useEffect(() => {
    if (!shipment?.id) return;
    const channel = supabase
      .channel(`admin-shipment-${shipment.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "shipments", filter: `id=eq.${shipment.id}` }, () => {
        qc.invalidateQueries({ queryKey: ["shipment", id] });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [shipment?.id, qc, id]);

  useEffect(() => {
    const done = !!shipment?.route_completed;
    if (prevCompletedRef.current === false && done) {
      toast.success(`Auto-route complete — package arrived at ${shipment?.route_to_name ?? "destination"}.`, { duration: 8000 });
    }
    prevCompletedRef.current = done;
  }, [shipment?.route_completed, shipment?.route_to_name]);

  const doGeocode = async (q: string, setResults: (r: GeocodeResult[]) => void) => {
    if (!q.trim()) {
      toast.message("Type a location first.");
      return;
    }
    setSearching(true);
    try {
      const r = await geocode(q);
      setResults(r);
      if (r.length === 0) toast.message("No matches found.");
    } catch (err: unknown) {
      setResults([]);
      toast.error(err instanceof Error ? err.message : "Location search failed");
    } finally {
      setSearching(false);
    }
  };

  const firstTypedLocationMatch = async (q: string) => {
    const trimmed = q.trim();
    if (!trimmed) return null;
    try {
      const results = await geocode(trimmed);
      return results[0] ?? null;
    } catch (err: unknown) {
      toast.warning(
        err instanceof Error
          ? `${err.message} Saving the typed location text instead.`
          : "Location search failed. Saving the typed location text instead.",
      );
      return null;
    }
  };

  const applyUpdate = async () => {
    if (!shipment) return;
    setUpdating(true);
    try {
      const selectedStatus = status || shipment.status;
      const locationWasEntered = Boolean(picked || locQuery.trim());
      const typedLocation = locationWasEntered ? picked ?? (await firstTypedLocationMatch(locQuery)) : null;
      const locationName = typedLocation?.display_name ?? locQuery.trim();
      const currentEta = shipment.estimated_delivery ? shipment.estimated_delivery.slice(0, 10) : "";
      const etaChanged = estimatedDelivery !== currentEta;
      const hasAnyUpdate =
        selectedStatus !== shipment.status ||
        locationWasEntered ||
        etaChanged ||
        Boolean(notes.trim());

      if (!hasAnyUpdate) {
        toast.message("Nothing to update.");
        return;
      }

      // Status workflow guard: no going backward, no skipping, no repeating a past status
      if (selectedStatus !== shipment.status) {
        const currentIdx = SHIPMENT_STATUSES.indexOf(shipment.status as typeof SHIPMENT_STATUSES[number]);
        const nextIdx = SHIPMENT_STATUSES.indexOf(selectedStatus as typeof SHIPMENT_STATUSES[number]);
        if (currentIdx === -1 || nextIdx === -1) {
          toast.error("Unknown status. Choose a valid workflow step.");
          return;
        }
        if (nextIdx < currentIdx) {
          toast.error(`Cannot move backward from "${shipment.status}" to "${selectedStatus}".`);
          return;
        }
        if (nextIdx > currentIdx + 1) {
          const expected = SHIPMENT_STATUSES[currentIdx + 1];
          toast.error(`Cannot skip stages. Next allowed status is "${expected}".`);
          return;
        }
        const alreadyUsed = events.some((e) => e.status === selectedStatus);
        if (alreadyUsed) {
          toast.error(`"${selectedStatus}" has already occurred and cannot repeat.`);
          return;
        }
        if (shipment.status === "Delivered" || shipment.status === "Completed") {
          toast.error("Delivered shipments are read-only.");
          return;
        }
      }

      // Contradiction guard: location country must match destination/recipient country
      if (locationWasEntered && locationName) {
        const destText = shipment.destination ?? shipment.recipient_address ?? "";
        if (destText && countriesConflict(locationName, destText)) {
          const locC = extractCountry(locationName);
          const dstC = extractCountry(destText);
          toast.error(`Location conflict: "${locC}" doesn't match destination country "${dstC}". Fix the address or location.`);
          return;
        }
      }

      // ETA sanity: cannot be earlier than shipment creation date
      if (etaChanged && estimatedDelivery) {
        const eta = new Date(`${estimatedDelivery}T12:00:00`);
        if (eta.getTime() < new Date(shipment.created_at).getTime()) {
          toast.error("Estimated delivery cannot be earlier than the shipment date.");
          return;
        }
      }

      const { error } = await supabase.rpc("admin_update_shipment", {
        _shipment_id: shipment.id,
        _status: selectedStatus,
        _location_provided: locationWasEntered,
        _location_name: locationWasEntered ? locationName : undefined,
        _lat: typedLocation?.lat,
        _lng: typedLocation?.lng,
        _set_estimated_delivery: etaChanged,
        _estimated_delivery: estimatedDelivery ? new Date(`${estimatedDelivery}T12:00:00`).toISOString() : undefined,
        _notes: notes.trim() || undefined,
      });
      if (error) throw error;

      toast.success("Shipment updated");
      setStatus("");
      setNotes(""); setPicked(null); setLocQuery(""); setLocResults([]);
      await qc.invalidateQueries({ queryKey: ["shipment", id] });
      await qc.invalidateQueries({ queryKey: ["admin-shipments"] });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Update failed");
    } finally {
      setUpdating(false);
    }
  };

  const saveScheduled = async () => {
    if (!shipment) return;
    if (!schedWhen) { toast.message("Pick a date & time."); return; }
    const typedScheduledLocation = schedPicked ?? (await firstTypedLocationMatch(schedLocQuery));
    if (!schedStatus && !typedScheduledLocation && !schedLocQuery.trim() && !schedNotes.trim()) {
      toast.message("Set at least a status, location, or notes."); return;
    }
    setSchedSaving(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("scheduled_updates").insert({
        shipment_id: shipment.id,
        scheduled_for: new Date(schedWhen).toISOString(),
        status: schedStatus || null,
        location_name: typedScheduledLocation?.display_name ?? (schedLocQuery.trim() || null),
        lat: typedScheduledLocation?.lat ?? null,
        lng: typedScheduledLocation?.lng ?? null,
        notes: schedNotes.trim() || null,
        created_by: u.user?.id,
      });
      if (error) throw error;
      toast.success("Scheduled");
      setSchedWhen(""); setSchedStatus(""); setSchedPicked(null);
      setSchedLocQuery(""); setSchedLocResults([]); setSchedNotes("");
      await qc.invalidateQueries({ queryKey: ["shipment", id] });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to schedule");
    } finally {
      setSchedSaving(false);
    }
  };

  const cancelScheduled = async (sid: string) => {
    const { error } = await supabase.from("scheduled_updates").delete().eq("id", sid);
    if (error) return toast.error(error.message);
    toast.success("Cancelled");
    qc.invalidateQueries({ queryKey: ["shipment", id] });
  };

  const startAutoRoute = async () => {
    if (!shipment) return;
    const from = routeFromPicked ?? (await firstTypedLocationMatch(routeFromQuery));
    const to = routeToPicked ?? (await firstTypedLocationMatch(routeToQuery));
    if (!from || !to) { toast.error("Pick valid From and To locations (search needs to resolve coordinates)."); return; }
    const destText = shipment.destination ?? shipment.recipient_address ?? "";
    if (destText && countriesConflict(to.display_name, destText)) {
      toast.error(`Auto-route destination "${extractCountry(to.display_name)}" doesn't match shipment destination "${extractCountry(destText)}".`);
      return;
    }
    if (countriesConflict(from.display_name, to.display_name)) {
      // cross-country routes are allowed but warn
      toast.warning("Route crosses countries — make sure that's intended.");
    }
    const totalSeconds =
      (Number(routeH) || 0) * 3600 +
      (Number(routeM) || 0) * 60 +
      (Number(routeS) || 0);
    if (!Number.isFinite(totalSeconds) || totalSeconds < 30) {
      toast.error("Duration must be at least 30 seconds.");
      return;
    }
    setRouteSaving(true);
    try {
      const { error } = await supabase.rpc("admin_set_auto_route", {
        _shipment_id: shipment.id,
        _from_lat: from.lat, _from_lng: from.lng, _from_name: from.display_name,
        _to_lat: to.lat, _to_lng: to.lng, _to_name: to.display_name,
        _duration_seconds: totalSeconds,
        _start_now: true,
      });
      if (error) throw error;
      toast.success("Auto-route started");
      setRouteFromQuery(""); setRouteToQuery(""); setRouteFromPicked(null); setRouteToPicked(null);
      qc.invalidateQueries({ queryKey: ["shipment", id] });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to start auto-route");
    } finally { setRouteSaving(false); }
  };

  const pauseAutoRoute = async () => {
    if (!shipment) return;
    const { error } = await supabase.rpc("admin_pause_auto_route", { _shipment_id: shipment.id });
    if (error) return toast.error(error.message);
    toast.success("Paused"); qc.invalidateQueries({ queryKey: ["shipment", id] });
  };
  const resumeAutoRoute = async () => {
    if (!shipment) return;
    const { error } = await supabase.rpc("admin_resume_auto_route", { _shipment_id: shipment.id });
    if (error) return toast.error(error.message);
    toast.success("Resumed"); qc.invalidateQueries({ queryKey: ["shipment", id] });
  };
  const clearAutoRoute = async () => {
    if (!shipment) return;
    if (!confirm("Stop and clear the auto-route?")) return;
    const { error } = await supabase.rpc("admin_clear_auto_route", { _shipment_id: shipment.id });
    if (error) return toast.error(error.message);
    toast.success("Cleared"); qc.invalidateQueries({ queryKey: ["shipment", id] });
  };

  const runNow = async () => {
    try {
      const result = await runDueScheduledUpdates();
      toast.success(`${result.applied} due update${result.applied === 1 ? "" : "s"} applied`);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to apply due updates");
    }
    qc.invalidateQueries({ queryKey: ["shipment", id] });
  };

  const deleteShipment = async () => {
    if (!shipment) return;
    if (!confirm("Delete this shipment and all its history?")) return;
    const { error } = await supabase.from("shipments").delete().eq("id", shipment.id);
    if (error) return toast.error(error.message);
    toast.success("Shipment deleted");
    qc.invalidateQueries({ queryKey: ["admin-shipments"] });
    window.location.href = "/admin";
  };

  return (
    <div className="min-h-screen">
      <header className="mx-auto max-w-6xl px-5 py-6 flex items-center justify-between">
        <Brand subtitle="Edit shipment" />
        <Link to="/admin" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-primary inline-flex items-center gap-1">
          <ArrowLeft className="h-3 w-3" /> Dashboard
        </Link>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-16">
        {isLoading || !shipment ? (
          <div className="text-muted-foreground">Loading…</div>
        ) : (
          <>
            <div className="rounded-2xl border border-border bg-card p-6 mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <div className="text-xs uppercase tracking-widest text-muted-foreground inline-flex items-center gap-1">
                    <Pencil className="h-3 w-3" /> Editing
                  </div>
                  <div className="font-mono text-2xl font-bold flex items-center gap-2">
                    {shipment.tracking_number}
                    <Button variant="ghost" size="icon" onClick={() => { navigator.clipboard.writeText(shipment.tracking_number); toast.success("Copied"); }}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {shipment.recipient_name ?? "—"} · {shipment.destination ?? "—"}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-primary/15 text-primary border-primary/30">{shipment.status}</Badge>
                  <Button variant="ghost" size="sm" onClick={deleteShipment} className="text-destructive hover:text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="grid lg:grid-cols-12 gap-6">
              <div className="lg:col-span-5 space-y-6">
                {/* Manual update */}
                <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
                  <h3 className="font-bold inline-flex items-center gap-2"><Pencil className="h-4 w-4 text-primary" /> Update now</h3>
                  <div>
                    <Label>Status</Label>
                    <Select value={status || shipment.status} onValueChange={setStatus}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {SHIPMENT_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Estimated delivery</Label>
                    <Input
                      type="date"
                      value={estimatedDelivery}
                      onChange={(e) => setEstimatedDelivery(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Search location</Label>
                    <div className="flex gap-2 mt-1">
                      <Input
                        value={locQuery}
                        onChange={(e) => { setLocQuery(e.target.value); setPicked(null); }}
                        placeholder="e.g. Mumbai, India"
                      />
                      <Button type="button" onClick={() => doGeocode(locQuery, setLocResults)} disabled={searching} variant="outline">
                        <Search className="h-4 w-4" />
                      </Button>
                    </div>
                    {locResults.length > 0 && (
                      <div className="mt-2 max-h-48 overflow-auto rounded-md border border-border divide-y divide-border">
                        {locResults.map((r, i) => (
                          <button key={i} type="button"
                            onClick={() => { setPicked(r); setLocResults([]); setLocQuery(r.display_name); }}
                            className="block w-full text-left px-3 py-2 text-xs hover:bg-secondary">
                            <MapPin className="h-3 w-3 inline mr-1 text-primary" />{r.display_name}
                          </button>
                        ))}
                      </div>
                    )}
                    {picked && (
                      <div className="mt-2 text-xs text-primary">
                        Selected: {picked.display_name} ({picked.lat.toFixed(4)}, {picked.lng.toFixed(4)})
                      </div>
                    )}
                    <p className="mt-2 text-xs text-muted-foreground">
                      If search fails, saving still updates the typed location and the customer map searches that address.
                    </p>
                  </div>
                  <div>
                    <Label>Notes (optional)</Label>
                    <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="e.g. Held at customs" />
                  </div>
                  <Button onClick={applyUpdate} disabled={updating} className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
                    {updating ? "Saving…" : "Save update"}
                  </Button>
                </div>

                {/* Schedule auto-update */}
                <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
                  <h3 className="font-bold inline-flex items-center gap-2"><Clock className="h-4 w-4 text-primary" /> Schedule auto-update</h3>
                  <p className="text-xs text-muted-foreground">
                    Set a future date/time. The system will automatically apply this update when due (checked every minute).
                  </p>
                  <div>
                    <Label>When</Label>
                    <Input type="datetime-local" value={schedWhen} onChange={(e) => setSchedWhen(e.target.value)} className="mt-1" />
                  </div>
                  <div>
                    <Label>Status (optional)</Label>
                    <Select value={schedStatus} onValueChange={setSchedStatus}>
                      <SelectTrigger className="mt-1"><SelectValue placeholder="Keep current" /></SelectTrigger>
                      <SelectContent>
                        {SHIPMENT_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Location (optional)</Label>
                    <div className="flex gap-2 mt-1">
                      <Input
                        value={schedLocQuery}
                        onChange={(e) => { setSchedLocQuery(e.target.value); setSchedPicked(null); }}
                        placeholder="e.g. Frankfurt, Germany"
                      />
                      <Button type="button" onClick={() => doGeocode(schedLocQuery, setSchedLocResults)} disabled={searching} variant="outline">
                        <Search className="h-4 w-4" />
                      </Button>
                    </div>
                    {schedLocResults.length > 0 && (
                      <div className="mt-2 max-h-40 overflow-auto rounded-md border border-border divide-y divide-border">
                        {schedLocResults.map((r, i) => (
                          <button key={i} type="button"
                            onClick={() => { setSchedPicked(r); setSchedLocResults([]); setSchedLocQuery(r.display_name); }}
                            className="block w-full text-left px-3 py-2 text-xs hover:bg-secondary">
                            <MapPin className="h-3 w-3 inline mr-1 text-primary" />{r.display_name}
                          </button>
                        ))}
                      </div>
                    )}
                    {schedPicked && <div className="mt-2 text-xs text-primary">Selected: {schedPicked.display_name}</div>}
                  </div>
                  <div>
                    <Label>Notes (optional)</Label>
                    <Textarea rows={2} value={schedNotes} onChange={(e) => setSchedNotes(e.target.value)} />
                  </div>
                  <Button onClick={saveScheduled} disabled={schedSaving} className="w-full font-bold" variant="outline">
                    {schedSaving ? "Scheduling…" : "Schedule update"}
                  </Button>
                </div>

                {/* Auto-move map route */}
                <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
                  <h3 className="font-bold inline-flex items-center gap-2"><RouteIcon className="h-4 w-4 text-primary" /> Auto-move on map</h3>
                  <p className="text-xs text-muted-foreground">
                    The package marker will slowly move from From → To over the duration. Updates tick every minute server-side and smoothly on the customer page.
                  </p>
                  {shipment.route_duration_seconds ? (
                    <div className="rounded-md border border-border p-3 text-xs space-y-1">
                      <div><b>From:</b> {shipment.route_from_name ?? "—"}</div>
                      <div><b>To:</b> {shipment.route_to_name ?? "—"}</div>
                      <div><b>Duration:</b> {formatDuration(shipment.route_duration_seconds)}</div>
                      <div>
                        <b>Status:</b>{" "}
                        {shipment.route_completed ? "✓ arrived"
                          : shipment.route_paused ? "⏸ paused"
                          : shipment.route_started_at ? "▶ moving" : "—"}
                      </div>
                      <div className="flex gap-2 pt-2">
                        {!shipment.route_completed && (shipment.route_paused
                          ? <Button size="sm" variant="outline" onClick={resumeAutoRoute}><Play className="h-3 w-3 mr-1" />Resume</Button>
                          : <Button size="sm" variant="outline" onClick={pauseAutoRoute}><Pause className="h-3 w-3 mr-1" />Pause</Button>)}
                        <Button size="sm" variant="ghost" onClick={clearAutoRoute} className="text-destructive"><X className="h-3 w-3 mr-1" />Clear</Button>
                      </div>
                    </div>
                  ) : null}

                  <div>
                    <Label>From</Label>
                    <div className="flex gap-2 mt-1">
                      <Input value={routeFromQuery} onChange={(e) => { setRouteFromQuery(e.target.value); setRouteFromPicked(null); }} placeholder="Origin city" />
                      <Button type="button" variant="outline" onClick={() => doGeocode(routeFromQuery, setRouteFromResults)}><Search className="h-4 w-4" /></Button>
                    </div>
                    {routeFromResults.length > 0 && (
                      <div className="mt-2 max-h-32 overflow-auto rounded-md border border-border divide-y divide-border">
                        {routeFromResults.map((r, i) => (
                          <button key={i} type="button" onClick={() => { setRouteFromPicked(r); setRouteFromQuery(r.display_name); setRouteFromResults([]); }} className="block w-full text-left px-3 py-2 text-xs hover:bg-secondary">
                            <MapPin className="h-3 w-3 inline mr-1 text-primary" />{r.display_name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label>To</Label>
                    <div className="flex gap-2 mt-1">
                      <Input value={routeToQuery} onChange={(e) => { setRouteToQuery(e.target.value); setRouteToPicked(null); }} placeholder="Destination city" />
                      <Button type="button" variant="outline" onClick={() => doGeocode(routeToQuery, setRouteToResults)}><Search className="h-4 w-4" /></Button>
                    </div>
                    {routeToResults.length > 0 && (
                      <div className="mt-2 max-h-32 overflow-auto rounded-md border border-border divide-y divide-border">
                        {routeToResults.map((r, i) => (
                          <button key={i} type="button" onClick={() => { setRouteToPicked(r); setRouteToQuery(r.display_name); setRouteToResults([]); }} className="block w-full text-left px-3 py-2 text-xs hover:bg-secondary">
                            <MapPin className="h-3 w-3 inline mr-1 text-primary" />{r.display_name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label>Duration</Label>
                    <div className="grid grid-cols-3 gap-2 mt-1">
                      <div>
                        <Input type="number" min="0" step="1" value={routeH} onChange={(e) => setRouteH(e.target.value)} />
                        <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1 text-center">hours</div>
                      </div>
                      <div>
                        <Input type="number" min="0" max="59" step="1" value={routeM} onChange={(e) => setRouteM(e.target.value)} />
                        <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1 text-center">minutes</div>
                      </div>
                      <div>
                        <Input type="number" min="0" max="59" step="1" value={routeS} onChange={(e) => setRouteS(e.target.value)} />
                        <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1 text-center">seconds</div>
                      </div>
                    </div>
                    <div className="text-[11px] text-muted-foreground mt-1">Minimum 30 seconds.</div>
                  </div>

                  <div>
                    <Label>Animation smoothness</Label>
                    <Select
                      value={shipment.animation_smoothness ?? "fluid"}
                      onValueChange={async (v) => {
                        const { error } = await supabase.rpc("admin_set_animation_smoothness", {
                          _shipment_id: shipment.id,
                          _smoothness: v,
                        });
                        if (error) return toast.error(error.message);
                        toast.success(`Smoothness: ${v}`);
                        qc.invalidateQueries({ queryKey: ["shipment", id] });
                      }}
                    >
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fluid">Fluid — sweeping second-hand glide</SelectItem>
                        <SelectItem value="standard">Standard — balanced correction</SelectItem>
                        <SelectItem value="instant">Instant — snap to server ticks</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="text-[11px] text-muted-foreground mt-1">
                      Controls how the marker corrects drift. Fluid never jumps.
                  </div>

                  <div>
                    <Label>Easing curve</Label>
                    <Select
                      value={shipment.animation_easing ?? "linear"}
                      onValueChange={async (v) => {
                        const { error } = await supabase.rpc("admin_set_animation_easing", {
                          _shipment_id: shipment.id,
                          _easing: v,
                        });
                        if (error) return toast.error(error.message);
                        toast.success(`Easing: ${v}`);
                        qc.invalidateQueries({ queryKey: ["shipment", id] });
                      }}
                    >
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="linear">Linear — constant speed</SelectItem>
                        <SelectItem value="ease-in-out">Ease in-out — gentle start &amp; arrival</SelectItem>
                        <SelectItem value="ease-out">Ease out — cruise then soft arrival</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="text-[11px] text-muted-foreground mt-1">
                      Shapes how the marker accelerates and decelerates along the route.
                    </div>
                  </div>

                  <label className="flex items-center gap-2 text-xs text-muted-foreground select-none cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showDiagnostics}
                      onChange={(e) => setShowDiagnostics(e.target.checked)}
                    />
                    Show real-time animation diagnostics on map
                  </label>
                  </div>

                  <Button onClick={startAutoRoute} disabled={routeSaving} className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
                    <Play className="h-4 w-4 mr-1" /> {routeSaving ? "Starting…" : "Start auto-route"}
                  </Button>
                </div>
              </div>

              <div className="lg:col-span-7 space-y-6">
                <div className="rounded-2xl border border-border bg-card p-2">
                  {shipment.current_lat != null && shipment.current_lng != null ? (
                    <Suspense fallback={<div className="h-[320px]" />}>
                      <TrackingMap
                        lat={shipment.current_lat}
                        lng={shipment.current_lng}
                        label={shipment.current_location_name ?? shipment.tracking_number}
                        height={320}
                        smoothness={shipment.animation_smoothness ?? "fluid"}
                        easing={shipment.animation_easing ?? "linear"}
                        debug={showDiagnostics}
                        route={
                          shipment.route_from_lat != null && shipment.route_to_lat != null && shipment.route_duration_seconds
                            ? {
                                fromLat: shipment.route_from_lat,
                                fromLng: shipment.route_from_lng!,
                                toLat: shipment.route_to_lat,
                                toLng: shipment.route_to_lng!,
                                startedAt: shipment.route_started_at,
                                elapsedSeconds: shipment.route_elapsed_seconds ?? 0,
                                durationSeconds: shipment.route_duration_seconds,
                                paused: !!shipment.route_paused,
                                completed: !!shipment.route_completed,
                              }
                            : null
                        }
                      />
                    </Suspense>
                  ) : shipment.current_location_name ? (
                    <Suspense fallback={<div className="h-[320px]" />}>
                      <TrackingMap label={shipment.current_location_name} height={320} />
                    </Suspense>
                  ) : (
                    <div className="h-[320px] flex items-center justify-center text-muted-foreground text-sm">
                      No location set yet.
                    </div>
                  )}
                </div>

                {/* Scheduled queue */}
                <div className="rounded-2xl border border-border bg-card p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold inline-flex items-center gap-2"><Clock className="h-4 w-4" /> Scheduled updates</h3>
                    <Button variant="ghost" size="sm" onClick={runNow} title="Apply any due updates now">
                      <Zap className="h-3 w-3 mr-1" /> Run due now
                    </Button>
                  </div>
                  {scheduled.length === 0 ? (
                    <div className="text-xs text-muted-foreground">No scheduled updates.</div>
                  ) : (
                    <div className="space-y-2">
                      {scheduled.map((s) => {
                        const due = new Date(s.scheduled_for);
                        const isApplied = !!s.applied_at;
                        return (
                          <div key={s.id} className="flex items-start justify-between gap-3 rounded-md border border-border p-3">
                            <div className="text-xs flex-1 min-w-0">
                              <div className="font-semibold">
                                {isApplied ? "✓ Applied" : "⏱ "}
                                {format(due, "PPpp")}
                              </div>
                              <div className="text-muted-foreground">
                                {s.status ?? "(keep status)"} · {s.location_name ?? "(keep location)"}
                              </div>
                              {s.notes && <div className="italic text-muted-foreground mt-1">{s.notes}</div>}
                            </div>
                            {!isApplied && (
                              <Button variant="ghost" size="icon" onClick={() => cancelScheduled(s.id)} className="text-destructive">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="rounded-2xl border border-border bg-card p-6">
                  <h3 className="font-bold mb-3">History</h3>
                  <div className="space-y-3">
                    {events.map((e, i) => (
                      <div key={e.id} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className={`h-3 w-3 rounded-full ${i === 0 ? "bg-primary ring-4 ring-primary/20" : "bg-muted-foreground/40"}`} />
                          {i < events.length - 1 && <div className="w-px flex-1 bg-border" />}
                        </div>
                        <div className="pb-3 flex-1">
                          <div className={`text-sm font-semibold ${i === 0 ? "text-primary" : ""}`}>{e.status}</div>
                          {e.location_name && (
                            <div className="text-xs text-muted-foreground flex items-center gap-1">
                              <MapPin className="h-3 w-3" /> {e.location_name}
                            </div>
                          )}
                          <div className="text-xs text-muted-foreground">{format(new Date(e.created_at), "PPpp")}</div>
                          {e.notes && <div className="text-xs text-muted-foreground italic mt-1">{e.notes}</div>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
