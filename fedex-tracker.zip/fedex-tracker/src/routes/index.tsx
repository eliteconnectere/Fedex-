import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, ShieldCheck, Globe2, Clock, MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FedEx — Track your shipment" },
      { name: "description", content: "Enter your FedEx tracking number to see live status, location and full shipment history on the map." },
      { property: "og:title", content: "FedEx — Track your shipment" },
      { property: "og:description", content: "Enter your FedEx tracking number to see live status, location and full shipment history on the map." },
    ],
  }),

  component: Home,
});

function Home() {
  const navigate = useNavigate();
  const [tn, setTn] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLink, setShowAdminLink] = useState(false);
  const tapsRef = useRef<number[]>([]);
  const hideTimerRef = useRef<number | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setIsAdmin(!!data.session));
  }, []);

  useEffect(() => {
    return () => {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    };
  }, []);

  const handleLogoTap = () => {
    const now = Date.now();
    tapsRef.current = [...tapsRef.current.filter((t) => now - t < 1500), now];
    if (tapsRef.current.length >= 3) {
      tapsRef.current = [];
      setShowAdminLink(true);
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
      hideTimerRef.current = window.setTimeout(() => setShowAdminLink(false), 3000);
    }
  };

  const onTrack = (e: React.FormEvent) => {
    e.preventDefault();
    const v = tn.trim().toUpperCase();
    if (!v) return;
    navigate({ to: "/track/$tn", params: { tn: v } });
  };

  return (
    <div className="min-h-screen">
      <header className="mx-auto max-w-6xl px-5 py-6 flex items-center justify-between">
        <div onClick={handleLogoTap} className="select-none">
          <Brand />
        </div>
        {(isAdmin || showAdminLink) ? (
          <Link
            to={isAdmin ? "/admin" : "/auth"}
            className="text-xs uppercase tracking-widest text-primary border border-primary/40 rounded-full px-3 py-1 animate-pulse"
          >
            {isAdmin ? "Admin Dashboard" : "Admin Login"}
          </Link>
        ) : (
          <span className="text-xs uppercase tracking-widest text-muted-foreground">
            Premium delivery
          </span>
        )}
      </header>

      <main className="mx-auto max-w-6xl px-5 pt-10 pb-24">
        <section className="grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 text-xs uppercase tracking-widest text-primary mb-6">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
              Live tracking active
            </div>
            <h1 className="text-5xl md:text-6xl font-black leading-[1.05] tracking-tight">
              Your package,<br />
              <span className="text-primary">across the globe</span>,<br />
              in real time.
            </h1>
            <p className="mt-5 text-lg text-muted-foreground max-w-xl">
              Enter your tracking number to see exactly where your shipment is — with live map,
              full delivery history, and estimated arrival.
            </p>

            <form onSubmit={onTrack} className="mt-8 flex flex-col sm:flex-row gap-3 max-w-xl">
              <Input
                value={tn}
                onChange={(e) => setTn(e.target.value)}
                placeholder="e.g. FX123456789012"
                className="h-14 text-base bg-card border-border tracking-wider"
                aria-label="Tracking number"
              />
              <Button type="submit" className="h-14 px-7 bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
                <Search className="mr-2 h-4 w-4" /> Track
              </Button>
            </form>


            <div className="mt-10 grid grid-cols-3 gap-6 max-w-xl">
              {[
                { icon: Globe2, label: "Worldwide" },
                { icon: Clock, label: "24/7 updates" },
                { icon: ShieldCheck, label: "Secure" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Icon className="h-4 w-4 text-primary" /> {label}
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="relative rounded-3xl border border-border bg-card p-6 shadow-2xl shadow-black/40 overflow-hidden">
              <div className="absolute -top-20 -right-20 h-60 w-60 rounded-full bg-primary/20 blur-3xl" />
              <div className="absolute -bottom-20 -left-20 h-60 w-60 rounded-full bg-accent/20 blur-3xl" />
              <div className="relative">
                <div className="text-xs uppercase tracking-widest text-muted-foreground">Tracking</div>
                <div className="mt-1 font-mono text-2xl font-bold tracking-wider">FX975704001505</div>

                <div className="mt-6 space-y-4">
                  {[
                    { s: "Out for Delivery", l: "Berlin Distribution Center", t: "Today, 09:14", active: true },
                    { s: "Arrived at Facility", l: "Berlin, DE", t: "Today, 04:22" },
                    { s: "In Transit", l: "Leipzig, DE", t: "Yesterday, 18:40" },
                    { s: "Shipment Created", l: "Frankfurt, DE", t: "2 days ago" },
                  ].map((e, i) => (
                    <div key={i} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className={`h-3 w-3 rounded-full ${e.active ? "bg-primary ring-4 ring-primary/20" : "bg-muted-foreground/40"}`} />
                        {i < 3 && <div className="w-px flex-1 bg-border" />}
                      </div>
                      <div className="pb-3">
                        <div className={`text-sm font-semibold ${e.active ? "text-primary" : ""}`}>{e.s}</div>
                        <div className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" /> {e.l} · {e.t}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 py-6 text-xs text-muted-foreground flex justify-between">
          <span>© FedEx</span>
          <span>Shipment Tracking</span>
        </div>
      </footer>

    </div>
  );
}
