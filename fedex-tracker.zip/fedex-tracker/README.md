# FedEx (29)

Create a complete shipment tracking system for a company named:

DHL Delivery Service

Company Owner / Administrator:
Name: Agent Neeraj
Email: agentneeraj57@gmail.com

Administrator Rules:
- Only Agent Neeraj can create, edit, update, and manage tracking records.
- Only Agent Neeraj can update shipment status and shipment location.
- No other user has administrative access.

Tracking System:
- Generate a unique Tracking Number automatically for every shipment.
- Each Tracking Number must be unique.
- The Tracking Number is the main identifier for the shipment.
- After creation, the Tracking Number is given to the customer.

Location System:
- The administrator can set the shipment location to any location worldwide.
- The administrator can update the location whenever the shipment moves.
- The latest location must be displayed to the customer.
- The customer should be able to view the shipment's current location on a map.
- The tracking page should focus on the exact location set by the administrator.

Customer Tracking:
- Customers do not need administrative access.
- Customers only need their Tracking Number.
- Customers can enter the Tracking Number and view:
  - Shipment Status
  - Current Location
  - Shipment Progress
  - Shipment History
  - Date and Time of Updates
  - Estimated Delivery Information

Shipment Status Examples:
- Shipment Created
- Package Received
- Processing
- In Transit
- Arrived at Facility
- Out for Delivery
- Delivered
- Completed

Update History:
- Every update must be saved.
- Every update must include date and time.
- Customers must be able to see the full tracking history.

Dashboard:
- Separate Administrator Dashboard.
- Separate Customer Tracking Page.
- Mobile-friendly design.
- Fast Tracking Number search.
- Clean and professional interface.

Main Workflow:
1. Agent Neeraj creates a shipment.
2. System generates a Tracking Number.
3. Agent Neeraj sets the shipment location.
4. Tracking Number is given to the customer.
5. Customer enters the Tracking Number.
6. Customer sees shipment status, map location, and tracking history.
7. Agent Neeraj updates location and status whenever necessary.
8. Customer sees the updates in real time.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://fedexmove-track.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/5642bdd7-12df-46d3-8917-c6664b539caa).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
