CREATE OR REPLACE FUNCTION public.process_scheduled_updates()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  r record;
  n integer := 0;
BEGIN
  FOR r IN
    SELECT * FROM public.scheduled_updates
    WHERE applied_at IS NULL AND scheduled_for <= now()
    ORDER BY scheduled_for ASC
  LOOP
    UPDATE public.shipments s SET
      status = COALESCE(r.status, s.status),
      current_location_name = COALESCE(r.location_name, s.current_location_name),
      current_lat = CASE WHEN r.location_name IS NOT NULL THEN r.lat ELSE s.current_lat END,
      current_lng = CASE WHEN r.location_name IS NOT NULL THEN r.lng ELSE s.current_lng END
    WHERE s.id = r.shipment_id;

    IF r.notes IS NOT NULL AND r.status IS NULL AND r.location_name IS NULL THEN
      INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
      SELECT s.id, s.status, s.current_location_name, s.current_lat, s.current_lng, r.notes
      FROM public.shipments s WHERE s.id = r.shipment_id;
    ELSIF r.notes IS NOT NULL THEN
      UPDATE public.tracking_events SET notes = r.notes
      WHERE id = (
        SELECT id
        FROM public.tracking_events
        WHERE shipment_id = r.shipment_id
        ORDER BY created_at DESC
        LIMIT 1
      );
    END IF;

    UPDATE public.scheduled_updates SET applied_at = now() WHERE id = r.id;
    n := n + 1;
  END LOOP;
  RETURN n;
END;
$$;