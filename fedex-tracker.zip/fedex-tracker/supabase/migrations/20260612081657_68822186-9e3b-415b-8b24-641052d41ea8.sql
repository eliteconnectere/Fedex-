
-- Roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Auto-grant admin to the designated email on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF lower(NEW.email) = 'agentneeraj57@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin')
    ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Shipments
CREATE TABLE public.shipments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tracking_number text UNIQUE NOT NULL,
  sender_name text,
  recipient_name text,
  recipient_address text,
  origin text,
  destination text,
  package_description text,
  weight_kg numeric,
  status text NOT NULL DEFAULT 'Shipment Created',
  current_location_name text,
  current_lat double precision,
  current_lng double precision,
  estimated_delivery timestamptz,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.shipments TO authenticated;
GRANT ALL ON public.shipments TO service_role;
ALTER TABLE public.shipments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins manage shipments" ON public.shipments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX shipments_tracking_idx ON public.shipments(tracking_number);

-- Tracking events
CREATE TABLE public.tracking_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid REFERENCES public.shipments(id) ON DELETE CASCADE NOT NULL,
  status text NOT NULL,
  location_name text,
  lat double precision,
  lng double precision,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracking_events TO authenticated;
GRANT ALL ON public.tracking_events TO service_role;
ALTER TABLE public.tracking_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins manage events" ON public.tracking_events FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX tracking_events_shipment_idx ON public.tracking_events(shipment_id, created_at DESC);

-- Updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER shipments_touch BEFORE UPDATE ON public.shipments
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- When admin updates shipment status/location, auto-create a tracking event
CREATE OR REPLACE FUNCTION public.log_shipment_change()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF (TG_OP = 'INSERT') OR
     (NEW.status IS DISTINCT FROM OLD.status) OR
     (NEW.current_location_name IS DISTINCT FROM OLD.current_location_name) THEN
    INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng)
    VALUES (NEW.id, NEW.status, NEW.current_location_name, NEW.current_lat, NEW.current_lng);
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER shipments_log_insert AFTER INSERT ON public.shipments
  FOR EACH ROW EXECUTE FUNCTION public.log_shipment_change();
CREATE TRIGGER shipments_log_update AFTER UPDATE ON public.shipments
  FOR EACH ROW EXECUTE FUNCTION public.log_shipment_change();

-- Public lookup RPC (callable by anon with tracking number)
CREATE OR REPLACE FUNCTION public.get_shipment_by_tracking(_tracking text)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s public.shipments;
  events jsonb;
BEGIN
  SELECT * INTO s FROM public.shipments WHERE tracking_number = upper(trim(_tracking)) LIMIT 1;
  IF NOT FOUND THEN
    RETURN NULL;
  END IF;
  SELECT COALESCE(jsonb_agg(to_jsonb(e) ORDER BY e.created_at DESC), '[]'::jsonb)
    INTO events FROM public.tracking_events e WHERE e.shipment_id = s.id;
  RETURN jsonb_build_object(
    'id', s.id,
    'tracking_number', s.tracking_number,
    'status', s.status,
    'sender_name', s.sender_name,
    'recipient_name', s.recipient_name,
    'recipient_address', s.recipient_address,
    'origin', s.origin,
    'destination', s.destination,
    'package_description', s.package_description,
    'weight_kg', s.weight_kg,
    'current_location_name', s.current_location_name,
    'current_lat', s.current_lat,
    'current_lng', s.current_lng,
    'estimated_delivery', s.estimated_delivery,
    'created_at', s.created_at,
    'updated_at', s.updated_at,
    'events', events
  );
END;
$$;
GRANT EXECUTE ON FUNCTION public.get_shipment_by_tracking(text) TO anon, authenticated;
