ALTER TABLE public.shipments
  ADD COLUMN IF NOT EXISTS animation_easing text NOT NULL DEFAULT 'linear'
  CHECK (animation_easing IN ('linear','ease-in-out','ease-out'));

CREATE OR REPLACE FUNCTION public.admin_set_animation_easing(_shipment_id uuid, _easing text)
RETURNS void
LANGUAGE plpgsql
SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins' USING ERRCODE = '42501';
  END IF;
  IF _easing NOT IN ('linear','ease-in-out','ease-out') THEN
    RAISE EXCEPTION 'Invalid easing value';
  END IF;
  PERFORM set_config('app.skip_shipment_auto_log', 'true', true);
  UPDATE public.shipments SET animation_easing = _easing WHERE id = _shipment_id;
END;
$$;

-- Refresh public tracking payload to include animation_easing
CREATE OR REPLACE FUNCTION public.get_shipment_by_tracking(_tracking text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  s public.shipments;
  events jsonb;
BEGIN
  SELECT * INTO s FROM public.shipments WHERE tracking_number = upper(trim(_tracking)) LIMIT 1;
  IF NOT FOUND THEN RETURN NULL; END IF;
  SELECT COALESCE(jsonb_agg(to_jsonb(e) ORDER BY e.created_at DESC), '[]'::jsonb)
    INTO events FROM public.tracking_events e WHERE e.shipment_id = s.id;
  RETURN jsonb_build_object(
    'id', s.id,
    'tracking_number', s.tracking_number,
    'status', s.status,
    'sender_name', s.sender_name,
    'recipient_name', s.recipient_name,
    'recipient_address', s.recipient_address,
    'origin', s.origin,
    'destination', s.destination,
    'package_description', s.package_description,
    'weight_kg', s.weight_kg,
    'current_location_name', s.current_location_name,
    'current_lat', s.current_lat,
    'current_lng', s.current_lng,
    'estimated_delivery', s.estimated_delivery,
    'created_at', s.created_at,
    'updated_at', s.updated_at,
    'route_from_lat', s.route_from_lat,
    'route_from_lng', s.route_from_lng,
    'route_from_name', s.route_from_name,
    'route_to_lat', s.route_to_lat,
    'route_to_lng', s.route_to_lng,
    'route_to_name', s.route_to_name,
    'route_duration_seconds', s.route_duration_seconds,
    'route_started_at', s.route_started_at,
    'route_elapsed_seconds', s.route_elapsed_seconds,
    'route_paused', s.route_paused,
    'route_completed', s.route_completed,
    'animation_smoothness', s.animation_smoothness,
    'animation_easing', s.animation_easing,
    'events', events
  );
END;
$$;