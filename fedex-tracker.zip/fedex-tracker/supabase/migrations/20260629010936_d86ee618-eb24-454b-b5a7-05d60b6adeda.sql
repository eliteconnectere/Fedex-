REVOKE ALL ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamp with time zone, boolean, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamp with time zone, boolean, text) TO authenticated;

REVOKE ALL ON FUNCTION public.process_scheduled_updates() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.process_scheduled_updates() TO authenticated;

REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;

REVOKE ALL ON FUNCTION public.get_shipment_by_tracking(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_shipment_by_tracking(text) TO anon, authenticated;

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.log_shipment_change() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.touch_updated_at() FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;