CREATE OR REPLACE FUNCTION public.process_scheduled_updates()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  r record;
  n integer := 0;
BEGIN
  FOR r IN
    SELECT * FROM public.scheduled_updates
    WHERE applied_at IS NULL AND scheduled_for <= now()
    ORDER BY scheduled_for ASC
  LOOP
    PERFORM set_config('app.skip_shipment_auto_log', 'true', true);

    UPDATE public.shipments s SET
      status = COALESCE(r.status, s.status),
      current_location_name = COALESCE(r.location_name, s.current_location_name),
      current_lat = CASE WHEN r.location_name IS NOT NULL THEN r.lat ELSE s.current_lat END,
      current_lng = CASE WHEN r.location_name IS NOT NULL THEN r.lng ELSE s.current_lng END
    WHERE s.id = r.shipment_id;

    INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
    SELECT s.id, s.status, s.current_location_name, s.current_lat, s.current_lng, NULLIF(btrim(COALESCE(r.notes, '')), '')
    FROM public.shipments s
    WHERE s.id = r.shipment_id;

    UPDATE public.scheduled_updates SET applied_at = now() WHERE id = r.id;
    n := n + 1;
  END LOOP;
  RETURN n;
END;
$function$;

REVOKE ALL ON FUNCTION public.process_scheduled_updates() FROM PUBLIC, anon, authenticated;