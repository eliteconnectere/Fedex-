
REVOKE EXECUTE ON FUNCTION public.tick_auto_routes() FROM anon, authenticated;
